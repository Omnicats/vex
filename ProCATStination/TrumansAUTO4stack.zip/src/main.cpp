/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Windward_Student                                 */
/*    Created:      Mon Sep 09 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"















//How it works
using namespace vex;

// A global instance of vex::brain used for printing to the V5 brain screen
vex::brain       Brain;
// A global instance of vex::competition
vex::competition Competition;


// define your global instances of motors and other devices here
motor LeftMotor = motor{PORT1}; 
motor RightMotor = motor{PORT11, true};
motor CenterMotor = motor{PORT3,true};
motor IntakeL = motor{PORT5};
motor IntakeR = motor{PORT6,true};






vex::rotationUnits rotations = vex::rotationUnits::rev;
int diamiter = 4;//inches
double circum = M_PI* diamiter; 
double robotwidth = 17.5;
double circLarge = 7.25;

void turn(double distinches, double circum){
  LeftMotor.startRotateFor(distinches/circum, rotationUnits::rev);
  RightMotor.rotateFor(-distinches/circum, rotationUnits::rev);
}

void forward(double distinches, double circum){
  LeftMotor.startRotateFor(distinches/circum, rotationUnits::rev);
  RightMotor.rotateFor(distinches/circum, rotationUnits::rev);
}

void strafeLeft(double distinches, double circum){
  CenterMotor.rotateFor(distinches/circum, rotationUnits::rev);//direction of strafe tbd after testing 
}
void strafeRight(double distinches, double circum){
  CenterMotor.rotateFor(-distinches/circum, rotationUnits::rev);//direction of strafe tbd after testing 
}

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the cortex has been powered on and    */ 
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton( void ) {
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  

  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous( void ) {
  
/*forward(24, circum);//forward 30 inches
*/
/*
forward(-24+5,circum);

strafeLeft(robotwidth, circum);

forward(24*1.5,circum);

forward(-10, circum);

strafeRight(24+5, circum);

forward(24, circum);

  vex::task::sleep(1000);
 
ejectblock(fwd);
*/

//360
turn((M_PI*7.25*7.25)/4,circum);//the robots 360degree circul = around 165.12996 in with full battery the robot travels x4 rotations or 1440 degrees
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to col your robot during the user control phase of */
/*  a VEX Competition.        ntro                                               */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol( void ) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo 
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to 
    // update your motors, etc.
    // ........................................................................
 
    vex::task::sleep(20); //Sleep the task for a short amount of time to prevent wasted resources. 
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    
    //Run the pre-autonomous function. 
    pre_auton();
       
    //Prevent main from exiting with an infinite loop.                        
    while(1) {
      vex::task::sleep(100);//Sleep the task for a short amount of time to prevent wasted resources.
    }    
       
}