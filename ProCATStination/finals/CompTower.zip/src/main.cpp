/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Windward_Student                                 */
/*    Created:      Sat Sep 07 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;

// A global instance of vex::brain used for printing to the V5 brain screen
vex::brain       Brain;
// A global instance of vex::competition
vex::competition Competition;

//declare motors
motor left = motor(PORT1); 
motor right = motor(PORT11, true);
motor center = motor(PORT3);

motor claw = motor(PORT20, true);


motor leftBar = motor(PORT5, true);
motor rightBar = motor(PORT6);

//digital_in sens = vex::digital_in(Brain.ThreeWirePort.G); //for limit switches
vex::sonar son = vex::sonar(Brain.ThreeWirePort.A);
vex::sonar sonBack = vex::sonar(Brain.ThreeWirePort.C);

controller input; 
// define your global instances of motors and other devices here
int MecPower = 50;
double coef = 1;
vex::rotationUnits rotations = vex::rotationUnits::rev;
int diamiter = 4;//inches
double circum = M_PI* diamiter; 
bool checkUltra = false;

void forward(double distinches, double circum){
  left.startRotateFor(fwd, distinches/circum, rotationUnits::rev, 50, velocityUnits::pct);
  right.rotateFor(fwd, distinches/circum, rotationUnits::rev, 50, velocityUnits::pct);
}
void backwards(double distinches, double circum){
  left.startRotateFor(distinches/circum, rotationUnits::rev);
  right.rotateFor(distinches/circum, rotationUnits::rev);
}

void strafeLeft(double distinches, double circum){
  center.rotateFor(fwd, distinches/circum, rotationUnits::rev, 50, velocityUnits::pct);
}
void strafeRight(double distinches, double circum){
  center.rotateFor(fwd, -distinches/circum, rotationUnits::rev, 50, velocityUnits::pct);
}
void grab(double x, double val){
  claw.spin(fwd,val, vex::velocityUnits::pct);
  vex::task::sleep(x);
  claw.stop();
  claw.setBrake(hold);
}
void lift(double Num){
  leftBar.setTimeout(5, vex::timeUnits::sec);
  rightBar.setTimeout(5, vex::timeUnits::sec);

  leftBar.startRotateTo(Num,vex::rotationUnits::deg);
  rightBar.rotateTo(Num,vex::rotationUnits::deg);
  /*
leftBar.setBrake(hold);
rightBar.setBrake(hold);
*/
}

void startLift(double Num){
  leftBar.setTimeout(5, vex::timeUnits::sec);
  rightBar.setTimeout(5, vex::timeUnits::sec);

  leftBar.startRotateTo(Num,vex::rotationUnits::deg);
  rightBar.rotateTo(Num,vex::rotationUnits::deg);
  /*
leftBar.setBrake(hold);
rightBar.setBrake(hold);
*/
}

void liftDist(double Num){

  //leftBar.setTimeout(5, vex::timeUnits::sec);
  //rightBar.setTimeout(5, vex::timeUnits::sec);
  leftBar.startRotateTo((Num*360)/7.5,vex::rotationUnits::deg);
  rightBar.rotateTo((Num*360)/7.5,vex::rotationUnits::deg);
  /*
leftBar.setBrake(hold);
rightBar.setBrake(hold);
*/
}
//20, 7
//30 ish


int getGroundCube(){
  if(input.ButtonB.pressing()){return -1;} //escape
  grab(1000, -15);
  while(son.distance(vex::distanceUnits::cm ) > 7){
  if(input.ButtonB.pressing()){return -1;} //escape
    left.spin(fwd, 20, pct);
    right.spin(fwd, 20, pct);
  }
  grab(1000, 15);
  return 1;
}

int placeOnCube(){
  if(input.ButtonB.pressing()){return -1;} //escape
  lift((7*360)/7.5);
  vex::task::sleep(600); //wait

   while(sonBack.distance(vex::distanceUnits::cm ) > 37){
    if(input.ButtonB.pressing()){return -1;} //escape
    left.spin(fwd, 10, pct);
    right.spin(fwd, 10, pct);
   }
   left.stop();
   right.stop();
    if(input.ButtonB.pressing()){return -1;} //escape
   lift(-(2*360)/7.5);
  grab(2000, 15);
  return 1;
}

/*
void centerCube(){
  double diff = (sonM2.distance(vex::distanceUnits::cm ) - sonM2.distance(vex::distanceUnits::cm ));
  while(diff > 5){
    right.spin(fwd, 5, pct);
  }
  while(diff < -5){
    left.spin(fwd, 5, pct);
  }
}
*/




/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the cortex has been powered on and    */ 
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton( void ) {
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  leftBar.setBrake(hold);
  rightBar.setBrake(hold);
  claw.setBrake(hold);
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous( void ) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  //mechanism.spin(fwd, -5, pct);
  //mec2.spin(fwd, 10, pct);
  //backwards(32, circum);
  //strafeLeft(9, circum);
  strafeRight(20, circum);
  strafeLeft(20, circum);
  forward(25, circum);

  strafeRight(2, circum);

  getGroundCube();
  forward(-10, circum); //meant to pick blocks up
  liftDist(17);
  forward(15, circum);
  grab(2000, 15);

  //strafeRight(12, circum);
  //forward(24, circum);

  //probably don't use this part
  

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol( void ) {
  // User control code here, inside the loop
  while (1) {
    left.spin(fwd, coef*(input.Axis3.value() + input.Axis4.value())/2, pct);
    right.spin(fwd, coef*(input.Axis3.value()-input.Axis4.value())/2, pct);
    center.spin(fwd, (input.Axis1.value()), pct);
    claw.spin(fwd, 20*(input.ButtonR1.pressing()-input.ButtonR2.pressing()), pct);

    rightBar.spin(fwd, 50*(input.ButtonL1.pressing() - input.ButtonL2.pressing()), vex::velocityUnits::pct);
    leftBar.spin(fwd, 50*(input.ButtonL1.pressing() - input.ButtonL2.pressing()), vex::velocityUnits::pct);

    /*
    if(input.ButtonR1.pressing()){//claw code
      claw.spin(vex::directionType::fwd, 15, vex::velocityUnits::pct);
    }else if (input.ButtonR2.pressing()) {
      claw.spin(vex::directionType::rev, 15, vex::velocityUnits::pct);
    }else{
      claw.stop(vex::brakeType::hold);
    }*/
  
  /*
    if(input.ButtonL1.pressing()){//6Bar Code
      rightBar.spin(vex::directionType::fwd, 30, vex::velocityUnits::pct);
      leftBar.spin(vex::directionType::fwd, 30, vex::velocityUnits::pct);
    }else if (input.ButtonL2.pressing()) {
      rightBar.spin(vex::directionType::rev, 30, vex::velocityUnits::pct);
      leftBar.spin(vex::directionType::rev, 30, vex::velocityUnits::pct);
    }else{
      leftBar.stop(vex::brakeType::hold);
      rightBar.stop(vex::brakeType::hold);
    }
    */
    /*
    if(sens.value() == 0){
      input.rumble(".-.-");
      //claw.spin(vex::directionType::rev, 50, vex::velocityUnits::pct);
    }
    */

      if(input.ButtonX.pressing()) {
        leftBar.stop(hold);
        right.stop(hold);
      }
      
      //if(input.ButtonY.pressing()) {
        //getGroundCube();
      //}

      if(input.ButtonB.pressing()){ //goes up to short tower
        //leftBar.setTimeout(25, vex::timeUnits::sec);
        //rightBar.setTimeout(25, vex::timeUnits::sec);

        leftBar.startRotateTo(20,vex::rotationUnits::deg);
        rightBar.rotateTo(20,vex::rotationUnits::deg);
      }

      if(input.ButtonA.pressing()){ //goes up by one cube
        //leftBar.setTimeout(5, vex::timeUnits::sec);
        //rightBar.setTimeout(5, vex::timeUnits::sec);

        leftBar.startRotateTo(6,vex::rotationUnits::deg);
        rightBar.rotateTo(6,vex::rotationUnits::deg);
      }


//Changing speed of drive
      if (input.ButtonUp.pressing()){coef += 0.2;}
      //if (input.ButtonDown.pressing() && coef > 0.4){coef -= 0.2;}
      if (input.ButtonRight.pressing()){coef = 1;}

    vex::task::sleep(20); //wait for a short amount of time - 20 msec = .02 seconds  
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    
    //Run the pre-autonomous function. 
    pre_auton();
       
    //Prevent main from exiting with an infinite loop.                        
    while(1) {
      vex::task::sleep(100);//Sleep the task for a short amount of time to prevent wasted resources.
    }    
       
}