/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Windward_Student                                 */
/*    Created:      Sat Sep 07 2019                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;

// A global instance of vex::brain used for printing to the V5 brain screen
vex::brain       Brain;
// A global instance of vex::competition
vex::competition Competition;

//declare motor 
motor left = motor(PORT1); 
motor mechanism = motor(PORT20);
motor right = motor(PORT11, true);
motor center = motor(PORT3);
motor leftintake = motor(PORT5, true);
motor rightintake = motor(PORT6);

//17, 2 and 7 dont work

controller input; 
// define your global instances of motors and other devices here
int MecPower = 50;

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the cortex has been powered on and    */ 
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton( void ) {
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous( void ) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol( void ) {
  // User control code here, inside the loop
  while (1) {
    left.spin(fwd, input.Axis3.value(), pct);
    right.spin(fwd, input.Axis2.value(), pct);
    //mechanism.spin(fwd, (MecPower*(input.ButtonA.pressing()-input.ButtonB.pressing())), pct);
    center.spin(fwd, (MecPower*(input.ButtonL1.pressing()-input.ButtonR1.pressing())), pct);
    leftintake.spin(fwd, (MecPower*(input.ButtonL2.pressing()-input.ButtonR2.pressing())), pct);
    rightintake.spin(fwd, (MecPower*(input.ButtonL2.pressing()-input.ButtonR2.pressing())), pct);
    vex::task::sleep(20); //wait for a short amount of time - 20 msec = .02 seconds  
    if(input.ButtonA.pressing()){
      mechanism.spin(fwd, (MecPower*input.ButtonA.pressing()), pct);
    }else if(input.ButtonB.pressing()){
      mechanism.spin(fwd, (-1*MecPower*input.ButtonB.pressing()), pct);
    }else{
      mechanism.stop(vex::brakeType::hold);
    }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
    //Set up callbacks for autonomous and driver control periods.
    Competition.autonomous( autonomous );
    Competition.drivercontrol( usercontrol );
    
    //Run the pre-autonomous function. 
    pre_auton();
       
    //Prevent main from exiting with an infinite loop.                        
    while(1) {
      vex::task::sleep(100);//Sleep the task for a short amount of time to prevent wasted resources.
    }    
       
}